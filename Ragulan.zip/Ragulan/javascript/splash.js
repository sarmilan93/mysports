//automatically navigate to main page
setTimeout(() => {
    window.location.href = 'html/products.html';
}, 4000)