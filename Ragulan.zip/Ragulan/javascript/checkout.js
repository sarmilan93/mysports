//variable declaration
var owner = $('#cname');
var ccnum = $('#ccnum');
var cvv = $('#cvv');
var fname = $('#fname');
var email = $('#email');
var adr = $('#adr');
var zip = $('#zip');
var totalAmount = 0;
var totalByItem = 0;

// Once UI is ready
$(document).ready(function () {

    var products = localStorage.getItem('products'); //getting products from local storage

    //validate credit card number & cvv through payform library
    ccnum.payform('formatCardNumber');
    cvv.payform('formatCardCVC');

    //display total no of items in the cart
    if(products){
        var data = JSON.parse(products);
        document.getElementsByClassName('cart-quantity')[0].textContent = data.length - 1;

        data.forEach(function (item, index) {
            if(index !== data.length - 1){
                listCartItems(item, index);
            }
        })
    }

    //dynamically create element to display products in the cart 
    function listCartItems(data, id){
        var productSummary = document.getElementsByClassName('products-summary')[0];
        totalByItem = data.quantity * data.price;
        totalAmount = totalAmount + totalByItem;
        var cartRowItems = `
                <p id="${id}" class="cart-qty"><a href="#">${data.name}</a> <a>Q: ${data.quantity}</a> <span class="price">$${totalByItem}</span></p>
            `
        var node = document.createElement("div"); 
        node.innerHTML = cartRowItems
        productSummary.appendChild(node);
        document.getElementsByClassName('total-amount')[0].textContent = "$" + totalAmount;
    }
});

//onclick event for "continue to checkout" button
function checkout(){
    var isCardValid = $.payform.validateCardNumber(ccnum.val());
    var isCvvValid = $.payform.validateCardCVC(cvv.val());
    if(totalAmount == 0){
        alert("The cart is empty!");
    }
    else {

        if(owner.val().length < 5){ // validate name on card
            alert("Wrong owner name");
        } else if (!isCardValid) { // validate credit card number
            alert("Wrong card number");
        } else if (!isCvvValid) { // validate cvv value
            alert("Wrong CVV");
        } else {
            if(fname.val() !== "" && email.val() !== "" && adr.val() !== "" && zip.val() !== "" ){
                localStorage.removeItem('products')
                totalAmount = 0;
                totalByItem = 0;
                console.log(fname.val(),email.val(),adr.val(),zip.val())
                alert("Thanks for your order!");
            }
            else {
                alert("Please fill all mandatory fields!");
            }
        }
    }
}